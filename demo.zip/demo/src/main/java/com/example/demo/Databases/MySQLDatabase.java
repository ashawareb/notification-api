package com.example.demo.Databases;

import com.example.demo.Operations.CRUD;
import com.example.demo.Templates.NotificationTemplate;

import java.sql.*;

public class MySQLDatabase implements IDatabase, CRUD {

    //Apply Singleton Pattern
    private static MySQLDatabase obj;

    private MySQLDatabase() {
    }

    public static synchronized MySQLDatabase GlobalObject() {
        if (obj == null) {
            obj = new MySQLDatabase();
        }
        return obj;
    }

    @Override
    public Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/Notification_System";
        String user = "root";
        String password = "Emadtarek563";
        Connection connection = null;
        connection = DriverManager.getConnection(url, user, password);

        return connection;
    }


    @Override
    public boolean create(NotificationTemplate notification) throws SQLException {
        String check = "";
        Connection connection = connectToDatabase();
        Statement stmt = connection.createStatement();
        String sql = "SELECT subject FROM Notification_Templates WHERE id=" + notification.getID();
        ResultSet res = stmt.executeQuery(sql);
        while (res.next()) {
            check += res.getString("subject");
            if (!check.equals("")) {
                System.out.println("There is template exist with the same ID");
                return false;
            }
        }
        String insertStr = notification.toString();
        sql = "INSERT INTO Notification_Templates(subject, body, id, language) VALUES(" + insertStr + ")";
        int check2 = stmt.executeUpdate(sql);
        return check2 > 0;
    }

    @Override
    public NotificationTemplate read(int id) throws SQLException {
        NotificationTemplate ob = null;
        Connection connection = connectToDatabase();
        Statement stmt = connection.createStatement();
        String sql = "SELECT subject FROM Notification_Templates WHERE id=" + id;
        ResultSet res = stmt.executeQuery(sql);
        while (res.next()) {
            ob.setSubject(res.getString("subject"));
            ob.setBody(res.getString("body"));
            ob.setID(id);
        }
        return ob;
    }

    @Override

    public boolean update(int id, NotificationTemplate notification) throws SQLException {
        Connection connection = connectToDatabase();
        PreparedStatement ps = null;
        String sql = "UPDATE Notification_Templates SET subject=?, body=? WHERE id=?";
        ps = connection.prepareStatement(sql);
        ps.setString(1, notification.getSubject());
        ps.setString(2, notification.getBody());
        ps.setInt(3, id);
        int check = ps.executeUpdate();
        return check > 0;
    }

    @Override
    public boolean delete(int id) throws SQLException {
        Connection connection = connectToDatabase();
        Statement stmt = connection.createStatement();
        String sql = "DELETE FROM Notification_Templates WHERE id=" + id;
        int check = stmt.executeUpdate(sql);
        return check > 0;
    }

}
