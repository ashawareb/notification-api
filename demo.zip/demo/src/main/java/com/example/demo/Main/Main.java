package com.example.demo.Main;

import com.example.demo.Databases.MySQLDatabase;

import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        Connection myConn = MySQLDatabase.GlobalObject().connectToDatabase();
        System.out.println();
        System.out.println();
        if (myConn == null) {
            System.out.println("NULL");
        } else {
            System.out.println("CONNECTED");
        }
    }
}
