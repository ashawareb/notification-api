package com.example.demo.api;

import com.example.demo.Operations.CRUD;
import com.example.demo.Templates.NotificationTemplate;

import java.sql.SQLException;

public class NotificationController implements CRUD {
    @Override
    public boolean create(NotificationTemplate notification) throws SQLException {
        return false;
    }

    @Override
    public NotificationTemplate read(int id) throws SQLException {
        return null;
    }

    @Override
    public boolean update(int id, NotificationTemplate notification) throws SQLException {
        return false;
    }

    @Override
    public boolean delete(int id) throws SQLException {
        return false;
    }
}
