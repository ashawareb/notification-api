package com.example.demo.Templates;

public enum Language {
    Arabic,
    English;
}
